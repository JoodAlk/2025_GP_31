import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:firebase_database/firebase_database.dart';

import 'bin_model.dart';

class DriverMapPage extends StatelessWidget {
  const DriverMapPage({super.key});

  @override
  Widget build(BuildContext context) {
    final DatabaseReference binsRef =
    FirebaseDatabase.instance.ref('Baseer/bins');


    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Bins Map View',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<DatabaseEvent>(
        stream: binsRef.onValue,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text('Error loading bins: ${snapshot.error}'),
            );
          }

          if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
            return const Center(
              child: Text('No bin locations found.'),
            );
          }

          final raw = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
          final List<Bin> bins = [];

          raw.forEach((key, value) {
            if (value is Map) {
              bins.add(Bin.fromRTDB(Map.from(value), key.toString()));
            }
          });

          if (bins.isEmpty) {
            return const Center(child: Text('No bins to display.'));
          }

          // Center map on first bin (later you can compute average)
          final first = bins.first;

          // Explicitly typed list to avoid InvalidType errors
          final List<Marker> markers = bins.map<Marker>((bin) {
            // Choose color by fill level
            Color color;
            if (bin.fillLevel >= 85) {
              color = Colors.red;
            } else if (bin.fillLevel >= 40) {
              color = Colors.orange;
            } else {
              color = Colors.green;
            }

              return Marker(
    width: 40,
    height: 40,
    alignment: Alignment.center,
    point: LatLng(bin.latitude, bin.longitude),
    child: GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Bin ${bin.id}'),
            content: Text('Fill level: ${bin.fillLevel}%'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
            ],
          ),
        );
      },
      child: Icon(
        Icons.delete, // trash bin icon
        color: color,
        size: 30,
      ),
    ),
  );

          }).toList();

          return FlutterMap(
            options: MapOptions(
              // flutter_map v8 uses `initialCenter` / `initialZoom`
              initialCenter: LatLng(first.latitude, first.longitude),
              initialZoom: 13,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.baseer',
              ),
              MarkerLayer(
                markers: markers,
              ),
            ],
          );
        },
      ),
    );
  }
}
