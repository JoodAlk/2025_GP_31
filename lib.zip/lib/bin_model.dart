import 'package:flutter/material.dart';

class Bin {
  final String id;
  final String name;
  final String areaId;
  final int fillLevel;
  final double latitude;
  final double longitude;

  Bin({
    required this.id,
    required this.name,
    required this.areaId,
    required this.fillLevel,
    required this.latitude,
    required this.longitude,
  });

  // Helper to safely parse ints from RTDB (int/double/String)
  static int _parseInt(dynamic value) {
    if (value is int) return value;
    if (value is double) return value.round();
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  static double _parseDouble(dynamic value) {
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  factory Bin.fromRTDB(Map data, String key) {
    final location = data['Location'] as Map?;

    final lat = _parseDouble(location?['Latitude']);
    final lng = _parseDouble(location?['Longitude']);

    return Bin(
      id: key, // e.g. "BIN-001"
      name: data['Name'] ?? 'N/A',
      areaId: data['AreaId'] ?? 'Unknown Area',
      fillLevel: _parseInt(data['FillLevel']),
      latitude: lat == 0.0 ? 24.7136 : lat,   // default: Riyadh
      longitude: lng == 0.0 ? 46.6753 : lng,
    );
  }

  String get statusText {
    if (fillLevel >= 85) return 'FULL';
    if (fillLevel >= 40) return 'HALF';
    return 'EMPTY';
  }

  Color get statusColor {
    if (fillLevel >= 85) return Colors.red.shade700;
    if (fillLevel >= 40) return Colors.orange.shade700;
    return Colors.green.shade700;
  }
}
