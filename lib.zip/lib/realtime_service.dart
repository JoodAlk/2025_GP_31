
import 'package:firebase_database/firebase_database.dart';

// Get a reference to the Firebase Realtime Database root
final DatabaseReference _dbRef = FirebaseDatabase.instance.ref();

// --- 1. DATA MODELS ------------------------

class Bin {
  final String id; 
  final String name;
  final String areaId;
  final int capacity;
  final int fillLevel;
  
  Bin({required this.id, required this.name, required this.areaId, required this.capacity, required this.fillLevel});
  
  Map<String, dynamic> toJson() {
    // Keys matching your JSON structure (e.g., 'AreaId', 'IsOverflowing')
    return {
      'Name': name,
      'AreaId': areaId,
      'Capacity': capacity,
      'FillLevel': fillLevel,
      'FreeSpace': capacity - fillLevel,
      'IsOverflowing': fillLevel >= 90,
      'IsAssigned': true,
      'AssignedDriverId': 'DRV-001',
      'LastEmptied': DateTime.now().toString(),
      'Location': {
        'Latitude': 24.7136,
        'Longitude': 46.6753,
      },
      'Sensor': {
        'Id': 'esp-81AC',
        'BatteryPct': 60,
      }
    };
  }
}

class Driver {
  final String id; 
  final String name;
  final String phone;
  
  Driver({required this.id, required this.name, required this.phone});
  
  Map<String, dynamic> toJson() {
    return {
      // Keys matching your JSON structure (e.g., 'DriverID', 'EmployeeNo')
      'DriverID': id,
      'Name': name,
      'Phone': phone,
      'EmployeeNo': '1099',
      'EmployeePass': '********',
      'IsWorking': true,
      'Language': 'en',
      'AssignedBinId': ['BIN-001', 'BIN-002'],
      'CurrentLocation': {
        'Latitude': 34.9876,
        'Longitude': 67.8876,
      }
    };
  }
}

class Admin {
  final String id; 
  final String name;
  final String email;
  
  Admin({required this.id, required this.name, required this.email});
  
  Map<String, dynamic> toJson() {
    return {
      // Keys matching your JSON structure (e.g., 'AdminID', 'Email')
      'AdminID': id,
      'Name': name,
      'Email': email,
      'EmployeeNo': 'ADM-001',
      'EmployeePass': '********',
    };
  }
}

// --- 2. CORE FUNCTIONS (Reusable by Entity) ----------------------------

// add data to a specific path 
Future<String> _addEntityStructured(String path, String key, Map<String, dynamic> data) async {
  await _dbRef.child('$path/$key').set(data);
  print('CONSOLE: ✅ $key added to $path');
  return key;
}

// update data at a specific path and key
Future<void> _updateEntity(String path, String key, Map<String, dynamic> data) async {
  await _dbRef.child('$path/$key').update(data);
  print('CONSOLE: ✅ $key updated in $path');
}

// delete data at a specific path and key
Future<void> _deleteEntity(String path, String key) async {
  await _dbRef.child('$path/$key').remove();
  print('CONSOLE: ✅ $key deleted from $path');
}


// --- 3. TEST EXECUTION: Comprehensive CRUD Cycle (12 Operations) ---

Future<void> runConsoleTests() async {
  print('------------------------------------------------');
  print('TEST START:');
  print('------------------------------------------------');

  const binPath = 'bins'; 
  const driverPath = 'drivers'; 
  const adminPath = 'admins'; 
  
  // --- A. CREATE PHASE: Add two of everything with structured IDs ---
  print('--- A. CREATE PHASE ---');
  
  // Bins (2)
  String binKeyA = 'BIN-002';
  String binKeyB = 'BIN-003';
  await _addEntityStructured(binPath, binKeyA, Bin(id: binKeyA, name: 'Bin A (Update)', areaId: 'Riyadh-d1', capacity: 120, fillLevel: 30).toJson());
  await _addEntityStructured(binPath, binKeyB, Bin(id: binKeyB, name: 'Bin B (Delete)', areaId: 'Riyadh-d2', capacity: 100, fillLevel: 70).toJson());

  // Drivers (2)
  String driverKeyA = 'DRV-002';
  String driverKeyB = 'DRV-003';
  await _addEntityStructured(driverPath, driverKeyA, Driver(id: driverKeyA, name: 'Driver A (Update)', phone: '+966111111111').toJson());
  await _addEntityStructured(driverPath, driverKeyB, Driver(id: driverKeyB, name: 'Driver B (Delete)', phone: '+966222222222').toJson());

  // Admins (2)
  String adminKeyA = 'ADM-002';
  String adminKeyB = 'ADM-003';
  await _addEntityStructured(adminPath, adminKeyA, Admin(id: adminKeyA, name: 'Admin A (Update)', email: 'adminA@baseer.com').toJson());
  await _addEntityStructured(adminPath, adminKeyB, Admin(id: adminKeyB, name: 'Admin B (Delete)', email: 'adminB@baseer.com').toJson());

  await Future.delayed(const Duration(milliseconds: 500));


  // --- B. UPDATE PHASE: Update the first entry of each entity ---
  print('--- B. UPDATE PHASE ---');
  
  // Update Bin A
  await _updateEntity(binPath, binKeyA, {'FillLevel': 95, 'IsOverflowing': true, 'Location/Latitude': 25.0});
  
  // Update Driver A
  await _updateEntity(driverPath, driverKeyA, {'IsWorking': false, 'CurrentLocation/Latitude': 35.0});
  
  // Update Admin A
  await _updateEntity(adminPath, adminKeyA, {'Email': 'supervisor.A@baseer.com'});
  
  await Future.delayed(const Duration(milliseconds: 500));


  // --- C. DELETE PHASE: Delete the second entry of each entity (Cleanup) ---
  print('--- C. DELETE PHASE ---');
  
  // Delete Bin B
  await _deleteEntity(binPath, binKeyB); 

  // Delete Driver B
  await _deleteEntity(driverPath, driverKeyB); 

  // Delete Admin B
  await _deleteEntity(adminPath, adminKeyB); 

  print('------------------------------------------------');
  print('TEST COMPLETE: 12 operations completed successfully ');
  print('------------------------------------------------');
}