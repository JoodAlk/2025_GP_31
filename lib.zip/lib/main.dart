import 'bin_model.dart';
import 'driver_map_page.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:developer' as developer;
import 'login_page.dart';

// NOTE: You must have a lib/realtime_service.dart file defining the Bin model and functions.

// Manual Firebase Configuration (Using your official credentials)
class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'AIzaSyBgzhlooyfDirhNsYww63URZfMhhl2DDhE',
    appId: '1:1080961954717:web:b681c3466cac60d704f574',
    messagingSenderId: '1080961954717',
    projectId: 'baseer-40cf2',
    databaseURL: 'https://baseer-40cf2-default-rtdb.asia-southeast1.firebasedatabase.app', 
  );
}



// --- Main App Entry Point ---

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    developer.log('Firebase initialized. Starting Dashboard.', name: 'APP');
  } catch (e) {
    developer.log('Error initializing Firebase: $e', name: 'ERROR');
  }

  runApp(const DriverApp());
}

class DriverApp extends StatelessWidget {
  const DriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Baseer Driver Dashboard',
      theme: ThemeData(
        primarySwatch: Colors.green,
        primaryColor: const Color(0xFF66BB6A), // Lighter Green from sketch
        scaffoldBackgroundColor: Colors.grey.shade50,
        useMaterial3: true,
      ),
      home: LoginPage(),
    );
  }
}

// --- Dashboard Screen (The main UI) ---

class BinDashboardScreen extends StatelessWidget {
  const BinDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // --- Top Bar (App Bar matching green sketch) ---
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: Theme.of(context).primaryColor,
        automaticallyImplyLeading: false, // Hides the back button
        title: const Padding(
          padding: EdgeInsets.only(top: 10.0),
          child: Text(
            'BASEER Driver View',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
        ),
        actions: [
          // Placeholder for the "Settings" eye icon from the sketch
          IconButton(
            icon: const Icon(Icons.remove_red_eye_outlined, color: Colors.white),
            onPressed: () {
              // Placeholder for future settings/profile screen
            },
          ),
          const SizedBox(width: 8),
        ],
      ),

      // --- Body: Real-time List Stream ---
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 16.0, bottom: 8.0),
            child: Text(
              'Bin Status (Filter by Fill Level)',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade600,
              ),
            ),
          ),
          const Expanded(
            child: BinDataStream(),
          ),
        ],
      ),
      
      // --- Bottom Navigation (Matching Green Sketch) ---
      bottomNavigationBar: BottomAppBar(
  color: Theme.of(context).primaryColor,
  height: 70,
  child: Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      // Route Button (unchanged)
      buildNavButton(
        icon: Icons.alt_route,
        label: 'Route',
        color: Colors.white,
        onTap: () {
          // Future route optimization logic goes here
        },
      ),

      // Map Button (opens the map page)
      buildNavButton(
        icon: Icons.place,
        label: 'Map',
        color: Colors.white,
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const DriverMapPage(),
            ),
          );
        },
      ),
    ],
  ),
),

  

    );
  }

  Widget buildNavButton({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

// --- Widget to Handle Data Stream from RTDB ---

class BinDataStream extends StatelessWidget {
  const BinDataStream({super.key});

  @override
  Widget build(BuildContext context) {
    // Reference to the root of the Bins data in RTDB
   final DatabaseReference binsRef =
    FirebaseDatabase.instance.ref('Baseer/bins');


    return StreamBuilder(
      stream: binsRef.onValue, // Listen for real-time changes
      builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error loading data: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
          return const Center(child: Text('No Bin data found in Realtime Database.'));
        }

        // --- Data Mapping ---
        // The RTDB data comes as a Map<dynamic, dynamic>
        final Map<dynamic, dynamic> data = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
        
        // Convert the map of bins into a list of Bin objects
        final List<Bin> binList = [];
        data.forEach((key, value) {
          // 'value' is the Map of bin properties; 'key' is the structured ID (e.g., BIN-001)
          if (value is Map) {
            binList.add(Bin.fromRTDB(Map.from(value), key.toString()));
          }
        });
        
        // Sort the list to prioritize FULL bins
        binList.sort((a, b) => b.fillLevel.compareTo(a.fillLevel));


        // --- Display List ---
        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          itemCount: binList.length,
          itemBuilder: (context, index) {
            final bin = binList[index];
            return BinListItem(bin: bin);
          },
        );
      },
    );
  }
}

// --- Widget to Display Each Bin (Matches Sketch Card Design) ---

class BinListItem extends StatelessWidget {
  final Bin bin;
  const BinListItem({super.key, required this.bin});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
        // Add a thin border line matching the sketch color based on status
        side: BorderSide(
          color: bin.statusColor.withOpacity(0.5), 
          width: 1.5
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
        child: Row(
          children: [
            // Left Side: Bin ID and Area
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Bin ID (bin 001)
                  Text(
                    bin.id,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Color(0xFF008080), // Teal/Turquoise from sketch
                    ),
                  ),
                  const SizedBox(height: 4),
                  // Area
                  Text(
                    'Area: ${bin.areaId}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
            
            // Right Side: Status Tag and Menu
            Row(
              children: [
                // Status Tag (FULL, HALF, EMPTY)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                  decoration: BoxDecoration(
                    color: bin.statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8.0),
                    border: Border.all(color: bin.statusColor, width: 1),
                  ),
                  child: Text(
                    bin.statusText.toUpperCase(),
                    style: TextStyle(
                      color: bin.statusColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Menu Button (Three Dots)
                IconButton(
                  icon: const Icon(Icons.more_vert, color: Colors.grey),
                  onPressed: () {
                    // Placeholder for future actions like 'Mark as Emptied' or 'Navigate'
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Tapped menu for Bin: ${bin.id}')),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}