import 'package:flutter/material.dart';

import 'driver_temp_password_storage.dart';
import 'driver_set_new_password_page.dart';

class DriverVerifyTempPasswordPage extends StatefulWidget {
  final String driverKey;

  const DriverVerifyTempPasswordPage({
    super.key,
    required this.driverKey,
  });

  @override
  State<DriverVerifyTempPasswordPage> createState() =>
      _DriverVerifyTempPasswordPageState();
}

class _DriverVerifyTempPasswordPageState
    extends State<DriverVerifyTempPasswordPage> {
  final TextEditingController tempPasswordController = TextEditingController();

  void _verifyTempPassword() {
    final entered = tempPasswordController.text.trim();

    if (entered.isEmpty) {
      _showDialog("Error", "Please enter the temporary password.");
      return;
    }

    if (!DriverTempPasswordStorage.verify(entered)) {
      _showDialog("Invalid Password", "The temporary password is incorrect.");
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => DriverSetNewPasswordPage(driverKey: widget.driverKey),
      ),
    );
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    tempPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets/images/Loginn.png",
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.35)),
          ),
          Center(
            child: Container(
              width: 420,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.93),
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset("assets/images/Logo.png", height: 60),
                  const SizedBox(height: 14),
                  const Text(
                    "Verify Temporary Password",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: tempPasswordController,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.lock_clock),
                      labelText: "Temporary Password",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _verifyTempPassword,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4CAF50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "Verify",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}