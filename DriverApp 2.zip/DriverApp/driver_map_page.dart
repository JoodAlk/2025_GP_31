import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:firebase_database/firebase_database.dart';

import 'bin_model.dart';
import 'app_frame.dart';
import 'routing/osrm_service.dart';

class DriverMapPage extends StatefulWidget {
  final List<Bin>? routeBins;
  final String? selectedArea;
  final bool showRouteLine;

  const DriverMapPage({
    super.key,
    this.routeBins,
    this.selectedArea,
    this.showRouteLine = false,
  });

  @override
  State<DriverMapPage> createState() => _DriverMapPageState();
}

class _DriverMapPageState extends State<DriverMapPage> {
  final _osrm = OsrmService();

  List<LatLng>? _roadPolyline;
  String? _routeError;

  @override
  void initState() {
    super.initState();
    _buildRoadPolylineIfNeeded();
  }

  @override
  void didUpdateWidget(covariant DriverMapPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.routeBins != widget.routeBins ||
        oldWidget.showRouteLine != widget.showRouteLine) {
      _buildRoadPolylineIfNeeded();
    }
  }

  Future<void> _buildRoadPolylineIfNeeded() async {
    final bins = widget.routeBins;

    if (!widget.showRouteLine || bins == null || bins.length < 2) {
      setState(() {
        _roadPolyline = null;
        _routeError = null;
      });
      return;
    }

    setState(() {
      _roadPolyline = null;
      _routeError = null;
    });

    try {
      final stops = bins.map((b) => LatLng(b.latitude, b.longitude)).toList();
      final poly = await _osrm.routeForStops(stops);

      if (!mounted) return;
      setState(() => _roadPolyline = poly);
    } catch (e) {
      if (!mounted) return;
      setState(() => _routeError = 'Road routing failed: $e');
    }
  }

  void _showBinDetails(BuildContext context, Bin bin) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Bin Details: ${bin.id}'),
        content: Text(
          'Fill Level: ${bin.fillLevel}%\n'
          'Area: ${bin.areaId}\n'
          'Lat: ${bin.latitude}\n'
          'Lng: ${bin.longitude}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppFrame(
      currentIndex: widget.routeBins != null ? 2 : 3,
      child: StreamBuilder<DatabaseEvent>(
        stream: FirebaseDatabase.instance.ref('Baseer/bins').onValue,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.snapshot.value == null) {
            return const Center(child: Text('No bin locations found.'));
          }

          final raw = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
          final List<Bin> allBins = [];

          raw.forEach((key, value) {
            if (value is Map) {
              allBins.add(Bin.fromRTDB(Map.from(value), key.toString()));
            }
          });

          final List<Bin> binsToShow = widget.routeBins ?? allBins;

          if (binsToShow.isEmpty) {
            return const Center(child: Text('No bins to display.'));
          }

          final first = binsToShow.first;

          final List<Marker> markers = [];
          for (int i = 0; i < binsToShow.length; i++) {
            final bin = binsToShow[i];

            markers.add(
              Marker(
                width: 60,
                height: 60,
                point: LatLng(bin.latitude, bin.longitude),
                child: GestureDetector(
                  onTap: () => _showBinDetails(context, bin),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Icon(Icons.delete, color: bin.statusColor, size: 38),
                      if (widget.routeBins != null)
                        Positioned(
                          top: 6,
                          right: 6,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.75),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '${i + 1}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            );
          }

          return Column(
            children: [
              if (widget.routeBins != null)
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  color: Colors.grey.shade100,
                  child: Text(
                    widget.showRouteLine
                        ? 'Active Route: ${widget.selectedArea ?? ''} (${binsToShow.length} stops)'
                        : 'Route Stops: ${widget.selectedArea ?? ''} (${binsToShow.length} stops)',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),

              if (widget.routeBins != null && !widget.showRouteLine)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DriverMapPage(
                              routeBins: widget.routeBins,
                              selectedArea: widget.selectedArea,
                              showRouteLine: true,
                            ),
                          ),
                        );
                      },
                      child: const Text('Start Route'),
                    ),
                  ),
                ),

              if (_routeError != null)
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  color: Colors.red.shade50,
                  child: Text(
                    _routeError!,
                    style: TextStyle(color: Colors.red.shade800),
                  ),
                ),

              Expanded(
                child: FlutterMap(
                  options: MapOptions(
                    initialCenter: LatLng(first.latitude, first.longitude),
                    initialZoom: 13,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'baseer.app',
                    ),
                    if (widget.showRouteLine &&
                        widget.routeBins != null &&
                        _roadPolyline != null)
                      PolylineLayer(
                        polylines: [
                          Polyline(
                            points: _roadPolyline!,
                            strokeWidth: 4,
                          ),
                        ],
                      ),
                    MarkerLayer(markers: markers),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}