class DriverTempPasswordStorage {
  static String? tempPassword;
  static String? driverKey;

  static bool verify(String enteredPassword) {
    return tempPassword != null && enteredPassword == tempPassword;
  }

  static void clear() {
    tempPassword = null;
    driverKey = null;
  }
}