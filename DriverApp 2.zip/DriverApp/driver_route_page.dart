import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import 'driver_map_page.dart';
import 'bin_model.dart';
import 'route_planner.dart';
import 'user_session.dart';

class DriverRoutePage extends StatelessWidget {
  const DriverRoutePage({super.key});

  @override
  Widget build(BuildContext context) {
    final assignedArea = UserSession.assignedArea;

    return FutureBuilder<DatabaseEvent>(
      future: FirebaseDatabase.instance.ref('Baseer/bins').once(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final raw = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
        final bins = <Bin>[];

        raw.forEach((key, value) {
          if (value is Map) {
            final b = Bin.fromRTDB(Map.from(value), key.toString());
            if (b.areaId == assignedArea) {
              bins.add(b);
            }
          }
        });

        final planner = RoutePlanner();
        final prioritySorted = planner.sortByPriority(List.of(bins));
        final route = planner.buildRouteStartingFromFirstPriority(prioritySorted);

        // Immediately open the map
        return DriverMapPage(
          routeBins: route,
          selectedArea: assignedArea,
          showRouteLine: false,
        );
      },
    );
  }
}