import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

import 'driver_home_page.dart';
import 'user_session.dart';
import 'driver_temp_password_storage.dart';
import 'driver_verify_temp_password_page.dart';
import 'driver_set_new_password_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;

  final TextEditingController idController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _fade = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    );

    _controller.forward();
  }

  String hashPassword(String password) {
    return sha256.convert(utf8.encode(password)).toString();
  }

  String _generateTemporaryPassword() {
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const all = upper + lower + numbers;
    final rnd = Random();

    return List.generate(8, (_) => all[rnd.nextInt(all.length)]).join();
  }

  void showPopup(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          )
        ],
      ),
    );
  }

  Future<void> loginDriver() async {
    final driverID = idController.text.trim();
    final password = passwordController.text.trim();

    if (driverID.isEmpty || password.isEmpty) {
      showPopup("Missing Fields", "Please enter Driver ID and password.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final ref = FirebaseDatabase.instance.ref("Baseer/drivers");
      final snapshot = await ref.get();

      bool success = false;

      if (snapshot.exists && snapshot.value != null) {
        for (var driver in snapshot.children) {
          final data = Map<dynamic, dynamic>.from(driver.value as Map);

          if ((data["DriverID"] ?? '').toString() == driverID) {
            final hashedInput = hashPassword(password);

            if (hashedInput == (data["EmployeePass"] ?? '').toString()) {
              success = true;

              UserSession.driverId = data["DriverID"]?.toString() ?? '';
              UserSession.name = data["Name"]?.toString() ?? '';
              UserSession.phone = data["Phone"]?.toString() ?? '';
              UserSession.assignedArea =
                  data["AssignedArea"]?.toString() ?? '';

              if (!mounted) return;

              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => const BinDashboardScreen(),
                ),
              );
              break;
            }
          }
        }
      }

      if (!success) {
        showPopup("Login Failed", "Invalid Driver ID or password.");
      }
    } catch (e) {
      showPopup("Error", e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showForgotDialog() {
    final forgotController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Forgot Password"),
        content: TextField(
          controller: forgotController,
          decoration: const InputDecoration(
            labelText: "Enter your Driver ID",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _handleForgotPassword(forgotController.text.trim());
            },
            child: const Text("Send"),
          ),
        ],
      ),
    );
  }

  Future<void> _handleForgotPassword(String driverId) async {
    if (driverId.isEmpty) {
      showPopup("Error", "Please enter your Driver ID.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final ref = FirebaseDatabase.instance.ref("Baseer/drivers");
      final snapshot = await ref.get();

      Map<String, dynamic>? foundDriver;
      String? foundKey;

      if (snapshot.exists && snapshot.value != null) {
        for (var driver in snapshot.children) {
          final data = Map<String, dynamic>.from(driver.value as Map);

          if ((data["DriverID"] ?? '').toString() == driverId) {
            foundDriver = data;
            foundKey = driver.key;
            break;
          }
        }
      }

      if (foundDriver == null || foundKey == null) {
        showPopup("Not Found", "No driver account matches this ID.");
        return;
      }

      final email = (foundDriver["Email"] ?? '').toString();

      if (email.isEmpty || email == "N/A") {
        showPopup(
          "Error",
          "This driver does not have an email registered.",
        );
        return;
      }

      final tempPassword = _generateTemporaryPassword();

      DriverTempPasswordStorage.tempPassword = tempPassword;
      DriverTempPasswordStorage.driverKey = foundKey;

      await _sendForgotPasswordEmail(
        email: email,
        name: (foundDriver["Name"] ?? '').toString(),
        temporaryPassword: tempPassword,
      );

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DriverVerifyTempPasswordPage(driverKey: foundKey!),
        ),
      );
    } catch (e) {
      showPopup("Error", e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _sendForgotPasswordEmail({
    required String email,
    required String name,
    required String temporaryPassword,
  }) async {
    const serviceId = 'service_k6q1xr4';
const templateId = 'template_4eutkwm';
const publicKey = 'C_LhjmeIfP-VVFNrw';

    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');

    final response = await http.post(
      url,
      headers: {
        'origin': 'http://localhost',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'service_id': serviceId,
        'template_id': templateId,
        'user_id': publicKey,
        'template_params': {
          'to_email': email,
          'to_name': name,
          'temp_password': temporaryPassword,
        }
      }),
    );

    if (response.statusCode != 200) {
  throw Exception(
    "Failed to send password recovery email: ${response.statusCode} - ${response.body}",
  );
}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/Loginn.png',
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.35)),
          ),
          Center(
            child: FadeTransition(
              opacity: _fade,
              child: Container(
                width: 340,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.93),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.15),
                      blurRadius: 25,
                      spreadRadius: 2,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      'assets/images/Logo.png',
                      height: 70,
                      fit: BoxFit.contain,
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "Driver Login",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: idController,
                      decoration: InputDecoration(
                        labelText: "Driver ID",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: passwordController,
                      obscureText: _obscurePassword,
                      decoration: InputDecoration(
                        labelText: "Password",
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility
                                : Icons.visibility_off,
                          ),
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: _isLoading ? null : _showForgotDialog,
                        child: const Text("Forgot Password?"),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF66BB6A),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: _isLoading ? null : loginDriver,
                        child: _isLoading
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : const Text(
                                "Login",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    idController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}