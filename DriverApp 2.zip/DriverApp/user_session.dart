// lib/user_session.dart

class UserSession {
  static String driverId = '';
  static String name = '';
  static String phone = '';
  static String assignedArea = '';
  static String employeeNo = '';

  static void clearSession() {
    driverId = '';
    name = '';
    phone = '';
    assignedArea = '';
    employeeNo = '';
  }
}