import 'package:flutter/material.dart';
import 'temp_password_storage.dart';
import 'set_new_password_page.dart';

class VerifyTempPasswordPage extends StatefulWidget {
  final String adminKey;

  const VerifyTempPasswordPage({super.key, required this.adminKey});

  @override
  State<VerifyTempPasswordPage> createState() =>
      _VerifyTempPasswordPageState();
}

class _VerifyTempPasswordPageState extends State<VerifyTempPasswordPage> {
  final TextEditingController tempPasswordController = TextEditingController();
  bool _isLoading = false;
  bool _obscureTemp = true;

  void _verifyTempPassword() {
    final entered = tempPasswordController.text.trim();

    if (entered.isEmpty) {
      _showDialog("Error", "Please enter the temporary password.");
      return;
    }

    if (TempPasswordStorage.tempPassword == null ||
        TempPasswordStorage.adminKey != widget.adminKey) {
      _showDialog(
        "Session Expired",
        "Temporary password is no longer available. Please try again.",
      );
      return;
    }

    if (entered != TempPasswordStorage.tempPassword) {
      _showDialog("Error", "Incorrect temporary password.");
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => SetNewPasswordPage(adminKey: widget.adminKey),
      ),
    );
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    tempPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets/images/Loginn.png",
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.35)),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: Container(
                padding: const EdgeInsets.all(24),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.92),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.15),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    )
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset("assets/images/Logo.png", height: 60),
                    const SizedBox(height: 10),
                    const Text(
                      "Verify Temporary Password",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "Please enter the temporary password sent to your email.",
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),

                    TextField(
                      controller: tempPasswordController,
                      obscureText: _obscureTemp,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock_outline),
                        labelText: "Temporary Password",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureTemp
                                ? Icons.visibility
                                : Icons.visibility_off,
                          ),
                          onPressed: () {
                            setState(() {
                              _obscureTemp = !_obscureTemp;
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4CAF50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: _isLoading ? null : _verifyTempPassword,
                        child: const Text(
                          "Verify",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}