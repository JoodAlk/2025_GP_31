import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

import 'admin_homepage.dart';
import 'admin_user_session.dart';
import 'temp_password_storage.dart';
import 'verify_temp_password_page.dart';

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref('Baseer');

  final _formKey = GlobalKey<FormState>();
  final TextEditingController identifierController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _isLoading = false;

  String _hashPassword(String password) {
    return sha256.convert(utf8.encode(password)).toString();
  }

  String _normalizeIdentifier(String identifier) {
    final trimmed = identifier.trim();
    if (RegExp(r'^5\d{8}$').hasMatch(trimmed)) {
      return "+966$trimmed";
    }
    return trimmed;
  }

  String _generateTemporaryPassword() {
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const all = upper + lower + numbers;

    final rnd = Random();

    return List.generate(
      8,
      (_) => all[rnd.nextInt(all.length)],
    ).join();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final identifier = _normalizeIdentifier(identifierController.text);
    final password = passwordController.text.trim();
    final hashed = _hashPassword(password);

    setState(() => _isLoading = true);

    try {
      final adminsSnap = await _dbRef.child("admins").get();

      if (!adminsSnap.exists || adminsSnap.value == null) {
        _showDialog("Error", "No admins found.");
        return;
      }

      final raw = adminsSnap.value;
      bool found = false;
      Map<String, dynamic>? foundAdmin;
      String? adminKey;

      void tryLogin(dynamic admin, String key) {
        if (admin == null || admin is! Map) return;

        final email = (admin['Email'] ?? '').toString().trim();
        final phone = (admin['Phone'] ?? '').toString().trim();
        final storedPass = (admin['EmployeePass'] ?? '').toString().trim();

        if ((identifier == email || identifier == phone) &&
            storedPass == hashed) {
          found = true;
          foundAdmin = Map<String, dynamic>.from(admin);
          adminKey = key;
        }
      }

      if (raw is List) {
        for (int i = 0; i < raw.length; i++) {
          tryLogin(raw[i], i.toString());
          if (found) break;
        }
      } else if (raw is Map) {
        final map = Map<dynamic, dynamic>.from(raw);
        for (final entry in map.entries) {
          tryLogin(entry.value, entry.key.toString());
          if (found) break;
        }
      }

      if (!found || foundAdmin == null || adminKey == null) {
        _showDialog("Login Failed", "Invalid credentials.");
        return;
      }

      await AdminUserSession.saveSession(
        dbKey: adminKey!,
        id: (foundAdmin!['AdminID'] ?? '').toString(),
        name: (foundAdmin!['Name'] ?? '').toString(),
        email: (foundAdmin!['Email'] ?? '').toString(),
        phone: (foundAdmin!['Phone'] ?? '').toString(),
        role: (foundAdmin!['Role'] ?? 'admin').toString(),
      );

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const AdminHomePage()),
      );
    } catch (e) {
      _showDialog("Error", e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showForgotDialog() {
    final forgotController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Forgot Password"),
        content: TextField(
          controller: forgotController,
          decoration: const InputDecoration(
            labelText: "Enter your email or phone number",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _handleForgotPassword(forgotController.text.trim());
            },
            child: const Text("Send"),
          ),
        ],
      ),
    );
  }

  Future<void> _handleForgotPassword(String input) async {
    if (input.isEmpty) {
      _showDialog("Error", "Please enter your email or phone number.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final normalizedInput = _normalizeIdentifier(input);
      final adminsSnap = await _dbRef.child("admins").get();

      if (!adminsSnap.exists || adminsSnap.value == null) {
        _showDialog("Error", "No admins found.");
        return;
      }

      final raw = adminsSnap.value;
      Map<String, dynamic>? foundAdmin;
      String? foundKey;

      void findUser(dynamic admin, String key) {
        if (admin == null || admin is! Map) return;

        final email = (admin['Email'] ?? '').toString().trim();
        final phone = (admin['Phone'] ?? '').toString().trim();

        if (normalizedInput == email || normalizedInput == phone) {
          foundAdmin = Map<String, dynamic>.from(admin);
          foundKey = key;
        }
      }

      if (raw is List) {
        for (int i = 0; i < raw.length; i++) {
          findUser(raw[i], i.toString());
          if (foundAdmin != null) break;
        }
      } else if (raw is Map) {
        final map = Map<dynamic, dynamic>.from(raw);
        for (final entry in map.entries) {
          findUser(entry.value, entry.key.toString());
          if (foundAdmin != null) break;
        }
      }

      if (foundAdmin == null || foundKey == null) {
        _showDialog("Not Found", "No account matches that email or phone.");
        return;
      }

      final tempPassword = _generateTemporaryPassword();

      TempPasswordStorage.tempPassword = tempPassword;
      TempPasswordStorage.identifier = normalizedInput;
      TempPasswordStorage.adminKey = foundKey;

      await _sendForgotPasswordEmail(
        email: (foundAdmin!['Email'] ?? '').toString(),
        name: (foundAdmin!['Name'] ?? '').toString(),
        temporaryPassword: tempPassword,
      );

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VerifyTempPasswordPage(adminKey: foundKey!),
        ),
      );
    } catch (e) {
      _showDialog("Error", e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _sendForgotPasswordEmail({
    required String email,
    required String name,
    required String temporaryPassword,
  }) async {
    const serviceId = 'service_k6q1xr4';
    const templateId = 'template_4eutkwm';
    const publicKey = 'C_LhjmeIfP-VVFNrw';

    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');

    final response = await http.post(
      url,
      headers: {
        'origin': 'http://localhost',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'service_id': serviceId,
        'template_id': templateId,
        'user_id': publicKey,
        'template_params': {
          'to_email': email,
          'to_name': name,
          'temp_password': temporaryPassword,
        }
      }),
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to send forgot-password email.");
    }
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    identifierController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets/images/Loginn.png",
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.35)),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: Container(
                padding: const EdgeInsets.all(24),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.92),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.15),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    )
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset("assets/images/Logo.png", height: 60),
                      const SizedBox(height: 10),
                      const Text(
                        "Admin Login",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: identifierController,
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.person_outline),
                          labelText: "Email or Phone Number",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (v) =>
                            (v == null || v.trim().isEmpty) ? "Required" : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: passwordController,
                        obscureText: _obscurePassword,
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.lock_outline),
                          labelText: "Password",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscurePassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            onPressed: () => setState(
                              () => _obscurePassword = !_obscurePassword,
                            ),
                          ),
                        ),
                        validator: (v) =>
                            (v == null || v.isEmpty) ? "Required" : null,
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: _isLoading ? null : _showForgotDialog,
                          child: const Text("Forgot Password?"),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF4CAF50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 0,
                          ),
                          onPressed: _isLoading ? null : _login,
                          child: _isLoading
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text(
                                  "Login",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}