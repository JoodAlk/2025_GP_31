import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'web_frame.dart';

class AdminDriverManagement extends StatefulWidget {
  const AdminDriverManagement({super.key});

  @override
  State<AdminDriverManagement> createState() => _AdminDriverManagementState();
}

class _AdminDriverManagementState extends State<AdminDriverManagement> {
  final DatabaseReference _dbRef =
      FirebaseDatabase.instance.ref('Baseer/drivers');

  final List<String> _areas = [
    'Riyadh-01',
    'Riyadh-02',
    'Riyadh-03',
    'Riyadh-04',
  ];

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  String hashPassword(String password) {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  bool isPhoneValid(String phone) {
    return RegExp(r'^\+9665[0-9]{8}$').hasMatch(phone);
  }

  bool isEmailValid(String email) {
    return RegExp(r'^[\w\-.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  String generateSecurePassword() {
    const uppers = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowers = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const specials = '!@#\$%^&*';
    final rnd = Random();

    String pass = '';
    pass += uppers[rnd.nextInt(uppers.length)];
    pass += lowers[rnd.nextInt(lowers.length)];
    pass += numbers[rnd.nextInt(numbers.length)];
    pass += specials[rnd.nextInt(specials.length)];

    const all = uppers + lowers + numbers + specials;
    for (int i = 0; i < 4; i++) {
      pass += all[rnd.nextInt(all.length)];
    }

    final chars = pass.split('');
    chars.shuffle(rnd);
    return chars.join('');
  }

  Future<void> _sendEmailToDriver(
    String email,
    String name,
    String id,
    String password,
  ) async {
    const serviceId = 'service_k6q1xr4';
    const templateId = 'template_s41tpxh';
    const publicKey = 'C_LhjmeIfP-VVFNrw';

    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'service_id': serviceId,
        'template_id': templateId,
        'user_id': publicKey,
        'template_params': {
          'to_email': email,
          'to_name': name,
          'id': id,
          'password': password,
        }
      }),
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to send email.");
    }
  }

  void _showAddDriverDialog() {
    _nameController.clear();
    _phoneController.clear();
    _emailController.clear();

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          "Add New Driver",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "A secure ID and password will be automatically generated and sent by email.",
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: "Full Name",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: "Email Address",
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: "Phone Number (5XXXXXXXX)",
                  prefixIcon: Icon(Icons.phone),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF81C784),
            ),
            onPressed: () async {
              final name = _nameController.text.trim();
              final email = _emailController.text.trim();
              String phone = _phoneController.text.trim();

              if (name.isEmpty || email.isEmpty || phone.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Please fill all fields"),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              if (!isEmailValid(email)) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Enter a valid email"),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              if (phone.startsWith("5")) {
                phone = "+966$phone";
              }

              if (!isPhoneValid(phone)) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Enter a valid Saudi phone number: 5XXXXXXXX"),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              final snapshot = await _dbRef.get();
              int maxKey = 0;

              if (snapshot.exists && snapshot.value != null) {
                final raw = snapshot.value;

                if (raw is List) {
                  for (int i = 0; i < raw.length; i++) {
                    if (raw[i] != null && i > maxKey) {
                      maxKey = i;
                    }
                  }
                } else if (raw is Map) {
                  final map = Map<dynamic, dynamic>.from(raw);
                  for (final key in map.keys) {
                    final parsed = int.tryParse(key.toString()) ?? 0;
                    if (parsed > maxKey) maxKey = parsed;
                  }
                }
              }

              final nextNumber = maxKey + 1;
              final driverID = "D$nextNumber";
              final rawPassword = generateSecurePassword();
              final hashedPassword = hashPassword(rawPassword);

              await _dbRef.child(nextNumber.toString()).set({
                "DriverID": driverID,
                "Name": name,
                "Phone": phone,
                "Email": email,
                "EmployeePass": hashedPassword,
                "IsWorking": false,
                "Language": "en",
                "AssignedBinsId": "",
                "CurrentLocation": "",
                "AssignedArea": "None",
              });

              await _sendEmailToDriver(email, name, driverID, rawPassword);

              if (!mounted) return;
              Navigator.of(dialogContext).pop();

              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text(
                    "Success",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  content: const Text(
                    "Driver created and credentials sent by email.",
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("OK"),
                    )
                  ],
                ),
              );
            },
            child: const Text(
              "Create Driver",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditDriverDialog(String driverKey, dynamic currentData) {
    final TextEditingController editNameController =
        TextEditingController(text: (currentData['Name'] ?? '').toString());
    final TextEditingController editPhoneController =
        TextEditingController(text: (currentData['Phone'] ?? '').toString());
    final TextEditingController editEmailController =
        TextEditingController(text: (currentData['Email'] ?? '').toString());

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          "Edit Driver: ${(currentData['DriverID'] ?? '').toString()}",
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: editNameController,
                decoration: const InputDecoration(
                  labelText: "Full Name",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: editEmailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: "Email Address",
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: editPhoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: "Phone Number",
                  prefixIcon: Icon(Icons.phone),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            onPressed: () async {
              String updatedPhone = editPhoneController.text.trim();

              if (updatedPhone.startsWith("5")) {
                updatedPhone = "+966$updatedPhone";
              }

              await _dbRef.child(driverKey).update({
                'Name': editNameController.text.trim(),
                'Email': editEmailController.text.trim(),
                'Phone': updatedPhone,
              });

              if (!mounted) return;
              Navigator.of(dialogContext).pop();

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Driver updated successfully!"),
                  backgroundColor: Colors.blue,
                ),
              );
            },
            child: const Text(
              "Save Changes",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _updateDriverArea(String driverKey, String newArea) {
    _dbRef.child(driverKey).update({'AssignedArea': newArea});
  }

  void _deleteDriver(String driverKey) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Driver"),
        content: const Text("Are you sure you want to delete this driver?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              _dbRef.child(driverKey).remove();
              Navigator.pop(context);
            },
            child: const Text(
              "Delete",
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  DataRow _buildDriverRow(String key, dynamic value) {
    final driverId = (value['DriverID'] ?? 'N/A').toString();
    final name = (value['Name'] ?? 'N/A').toString();
    final email = (value['Email'] ?? 'N/A').toString();
    final phone = (value['Phone'] ?? 'N/A').toString();
    final isWorking = value['IsWorking'] == true;
    final assignedArea = (value['AssignedArea'] ?? 'None').toString();

    return DataRow(
      cells: [
        DataCell(
          Text(
            driverId,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.blueGrey,
            ),
          ),
        ),
        DataCell(Text(name)),
        DataCell(Text(email)),
        DataCell(Text(phone)),
        DataCell(
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: isWorking ? Colors.green.shade50 : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              isWorking ? "On Route" : "Idle",
              style: TextStyle(
                color: isWorking ? Colors.green : Colors.grey,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ),
        DataCell(
          DropdownButton<String>(
            value: _areas.contains(assignedArea) ? assignedArea : null,
            hint: const Text("Assign Area"),
            underline: const SizedBox(),
            items: _areas
                .map((a) => DropdownMenuItem<String>(
                      value: a,
                      child: Text(a),
                    ))
                .toList(),
            onChanged: (newVal) {
              if (newVal != null) {
                _updateDriverArea(key, newVal);
              }
            },
          ),
        ),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit, color: Colors.blue),
                onPressed: () => _showEditDriverDialog(key, value),
                tooltip: "Edit Driver",
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () => _deleteDriver(key),
                tooltip: "Delete Driver",
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WebFrame(
      activeIndex: 3,
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Driver Management",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: _showAddDriverDialog,
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text(
                    "Add New Driver",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF81C784),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: StreamBuilder(
                  stream: _dbRef.onValue,
                  builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData ||
                        snapshot.data!.snapshot.value == null) {
                      return const Center(child: Text("No drivers found."));
                    }

                    final rawValue = snapshot.data!.snapshot.value;
                    List<DataRow> rows = [];

                    if (rawValue is Map) {
                      rawValue.forEach((key, value) {
                        if (value != null) {
                          rows.add(_buildDriverRow(key.toString(), value));
                        }
                      });
                    } else if (rawValue is List) {
                      for (int i = 0; i < rawValue.length; i++) {
                        if (rawValue[i] != null) {
                          rows.add(_buildDriverRow(i.toString(), rawValue[i]));
                        }
                      }
                    }

                    if (rows.isEmpty) {
                      return const Center(child: Text("No drivers found."));
                    }

                    return LayoutBuilder(
                      builder: (context, constraints) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minWidth: constraints.maxWidth),
                            child: SingleChildScrollView(
                              child: DataTable(
                                columnSpacing: 30,
                                columns: const [
                                  DataColumn(
                                    label: Text(
                                      "ID",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Name",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Email",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Phone",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Work Status",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Assigned Area",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Actions",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                                rows: rows,
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}