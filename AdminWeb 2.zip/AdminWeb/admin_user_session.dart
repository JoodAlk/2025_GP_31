import 'package:shared_preferences/shared_preferences.dart';

class AdminUserSession {

  static Future<void> saveSession({
    required String dbKey,
    required String id,
    required String name,
    required String email,
    required String phone,
    required String role,
    String? permissionKey,
  }) async {

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString('admin_db_key', dbKey);
    await prefs.setString('admin_id', id);
    await prefs.setString('admin_name', name);
    await prefs.setString('admin_email', email);
    await prefs.setString('admin_phone', phone);
    await prefs.setString('admin_role', role);

    if (permissionKey != null && permissionKey.isNotEmpty) {
      await prefs.setString('admin_permission', permissionKey);
    } else {
      await prefs.remove('admin_permission');
    }
  }

  static Future<Map<String, String?>> getSession() async {
    final prefs = await SharedPreferences.getInstance();

    return {
      'dbKey': prefs.getString('admin_db_key'),
      'id': prefs.getString('admin_id'),
      'name': prefs.getString('admin_name'),
      'email': prefs.getString('admin_email'),
      'phone': prefs.getString('admin_phone'),
      'role': prefs.getString('admin_role'),
      'permissionKey': prefs.getString('admin_permission'),
    };
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}