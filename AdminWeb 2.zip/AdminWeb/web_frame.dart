import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import 'admin_homepage.dart';
import 'admin_login_page.dart';
import 'admin_bin_management.dart';
import 'admin_map.dart';
import 'admin_driver_management.dart';
import 'admin_admin_management.dart';
import 'admin_user_session.dart';

class WebFrame extends StatefulWidget {
  final Widget body;
  final int activeIndex;

  const WebFrame({
    super.key,
    required this.body,
    this.activeIndex = -1,
  });

  @override
  State<WebFrame> createState() => _WebFrameState();
}

class _WebFrameState extends State<WebFrame> {
  bool _isProfileOpen = false;

  String _dbKey = "";
  String _adminId = "Loading...";
  String _adminName = "Loading...";
  String _adminEmail = "Loading...";
  String? _adminRole;

  @override
  void initState() {
    super.initState();
    _loadSessionData();
  }

  Future<void> _loadSessionData() async {
    final session = await AdminUserSession.getSession();

    setState(() {
      _dbKey = session['dbKey'] ?? "";
      _adminId = session['id'] ?? "Unknown";
      _adminName = session['name'] ?? "Unknown";
      _adminEmail = session['email'] ?? "Unknown";
      _adminRole = session['role'];
    });
  }

  void _navigate(BuildContext context, Widget page) {
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => page,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  Future<void> _handleLogout() async {
    await AdminUserSession.clearSession();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const AdminLoginPage()),
      (route) => false,
    );
  }

  void _showEditProfileDialog() {
    final nameCtrl = TextEditingController(text: _adminName);
    final emailCtrl = TextEditingController(text: _adminEmail);

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text("Edit Profile"),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: "Name"),
              ),
              const SizedBox(height: 10),
              const SizedBox(height: 10),
              TextField(
                controller: emailCtrl,
                decoration: const InputDecoration(labelText: "Email"),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF81C784),
            ),
            onPressed: () async {
              await FirebaseDatabase.instance
                  .ref('Baseer/admins/$_dbKey')
                  .update({
                'Name': nameCtrl.text.trim(),
                'Email': emailCtrl.text.trim(),
              });

              await AdminUserSession.saveSession(
                dbKey: _dbKey,
                id: _adminId,
                name: nameCtrl.text.trim(),
                email: emailCtrl.text.trim(),
                role: _adminRole ?? "admin", phone: '',
              );

              await _loadSessionData();

              if (!mounted) return;

              Navigator.pop(dialogContext);

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Profile updated successfully"),
                ),
              );
            },
            child: const Text(
              "Save Changes",
              style: TextStyle(color: Colors.white),
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: Stack(
        children: [
          Column(
            children: [
              _buildTopBar(),
              Expanded(child: widget.body),
            ],
          ),
          if (_isProfileOpen) _buildProfileOverlay(),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 80,
      decoration: BoxDecoration(
        color: const Color(0xFF81C784),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 180,
            height: double.infinity,
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(40),
                bottomRight: Radius.circular(40),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Image.asset(
              'assets/images/Logo.png',
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) => const Icon(
                Icons.remove_red_eye_outlined,
                color: Color(0xFF81C784),
                size: 40,
              ),
            ),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNavItem(Icons.dashboard, "Dashboard", 0, () {
                  if (widget.activeIndex != 0) {
                    _navigate(context, const AdminHomePage());
                  }
                }),
                _buildNavItem(Icons.delete_outline, "Bins", 1, () {
                  if (widget.activeIndex != 1) {
                    _navigate(context, const AdminBinManagement());
                  }
                }),
                _buildNavItem(Icons.map_outlined, "Map", 2, () {
                  if (widget.activeIndex != 2) {
                    _navigate(context, const AdminMapPage());
                  }
                }),
                _buildNavItem(Icons.drive_eta_outlined, "Drivers", 3, () {
                  if (widget.activeIndex != 3) {
                    _navigate(context, const AdminDriverManagement());
                  }
                }),
                if (_adminRole == "supervisor")
                  _buildNavItem(Icons.admin_panel_settings, "Admins", 4, () {
                    if (widget.activeIndex != 4) {
                      _navigate(context, const AdminManagementPage());
                    }
                  }),
                _buildNavItem(Icons.person, "Profile", -1, () {
                  setState(() => _isProfileOpen = !_isProfileOpen);
                }),
              ],
            ),
          ),
          const SizedBox(width: 20),
        ],
      ),
    );
  }

  Widget _buildProfileOverlay() {
    return GestureDetector(
      onTap: () => setState(() => _isProfileOpen = false),
      child: Container(
        color: Colors.black54,
        width: double.infinity,
        height: double.infinity,
        child: Stack(
          children: [
            Positioned(
              top: 90,
              right: 24,
              child: Container(
                width: 320,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFFE1F5FE),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black45,
                      blurRadius: 15,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Center(
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 35,
                            backgroundColor: Colors.blue.shade200,
                            child: const Icon(
                              Icons.person,
                              size: 40,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            "Admin Profile",
                            style: TextStyle(
                              color: Color(0xFF263238),
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(color: Colors.black12, height: 30),
                    _buildProfileRow("ID", _adminId),
                    _buildProfileRow("Name", _adminName),
                    _buildProfileRow("Email", _adminEmail),
                    if (_adminRole != null)
                      _buildProfileRow("Role", _adminRole!),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _showEditProfileDialog,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF81C784),
                              side: const BorderSide(
                                color: Color(0xFF81C784),
                                width: 3.0,
                              ),
                            ),
                            child: const Text(
                              "Edit",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: _handleLogout,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.redAccent,
                            ),
                            child: const Text(
                              "Logout",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
    IconData icon,
    String label,
    int index,
    VoidCallback onTap,
  ) {
    final isActive = widget.activeIndex == index;
    final color = isActive ? Colors.white : Colors.white60;

    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontWeight: isActive ? FontWeight.bold : FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "$label: ",
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 14,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.black87,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}