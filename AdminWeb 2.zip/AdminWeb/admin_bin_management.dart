import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'web_frame.dart';

class AdminBinManagement extends StatefulWidget {
  const AdminBinManagement({super.key});

  @override
  State<AdminBinManagement> createState() => _AdminBinManagementState();
}

class _AdminBinManagementState extends State<AdminBinManagement> {
  final DatabaseReference _dbRef =
      FirebaseDatabase.instance.ref('Baseer/bins');

  void _showAddBinDialog() {
    final nameController = TextEditingController();
    final areaController = TextEditingController();
    final latController = TextEditingController();
    final lngController = TextEditingController();
    final capacityController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          "Add New Bin",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: "Bin Name",
                  prefixIcon: Icon(Icons.delete_outline),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: areaController,
                decoration: const InputDecoration(
                  labelText: "Area ID",
                  prefixIcon: Icon(Icons.location_city),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: latController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "Latitude",
                  prefixIcon: Icon(Icons.pin_drop),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: lngController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "Longitude",
                  prefixIcon: Icon(Icons.pin_drop_outlined),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: capacityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Capacity",
                  prefixIcon: Icon(Icons.straighten),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF81C784),
            ),
            onPressed: () async {
              final name = nameController.text.trim();
              final area = areaController.text.trim();
              final lat = double.tryParse(latController.text.trim());
              final lng = double.tryParse(lngController.text.trim());
              final capacity = int.tryParse(capacityController.text.trim());

              if (name.isEmpty ||
                  area.isEmpty ||
                  lat == null ||
                  lng == null ||
                  capacity == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Please fill all fields correctly"),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              final snapshot = await _dbRef.get();
              int maxKey = 0;

              if (snapshot.exists && snapshot.value != null) {
                final raw = snapshot.value;

                if (raw is List) {
                  for (int i = 0; i < raw.length; i++) {
                    if (raw[i] != null && i > maxKey) {
                      maxKey = i;
                    }
                  }
                } else if (raw is Map) {
                  final map = Map<dynamic, dynamic>.from(raw);
                  for (final key in map.keys) {
                    final parsed = int.tryParse(key.toString()) ?? 0;
                    if (parsed > maxKey) maxKey = parsed;
                  }
                }
              }

              final nextNumber = maxKey + 1;
              final binId = "Bin-$nextNumber";

              await _dbRef.child(nextNumber.toString()).set({
                "BinID": binId,
                "Name": name,
                "AreaId": area,
                "LocationLatitude": lat,
                "LocationLongitude": lng,
                "Capacity": capacity,
                "FillLevel": 0,
                "IsOverflowing": false,
                "IsAssigned": false,
                "LastUpdate": "Just now",
                "Status": "OK",
              });

              if (!mounted) return;
              Navigator.of(dialogContext).pop();

              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text(
                    "Success",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  content: const Text("Bin added successfully."),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("OK"),
                    ),
                  ],
                ),
              );
            },
            child: const Text(
              "Add Bin",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _deleteBin(String key) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Bin"),
        content: const Text("Are you sure you want to delete this bin?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              _dbRef.child(key).remove();
              Navigator.pop(context);
            },
            child: const Text(
              "Delete",
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditBinDialog(String key, dynamic currentData) {
    final nameController =
        TextEditingController(text: (currentData['Name'] ?? '').toString());
    final areaController =
        TextEditingController(text: (currentData['AreaId'] ?? '').toString());
    final fillController = TextEditingController(
      text: (currentData['FillLevel'] ?? 0).toString(),
    );

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          "Edit Bin",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: "Bin Name",
                  prefixIcon: Icon(Icons.delete_outline),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: areaController,
                decoration: const InputDecoration(
                  labelText: "Area ID",
                  prefixIcon: Icon(Icons.location_city),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: fillController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Fill Level",
                  prefixIcon: Icon(Icons.percent),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            onPressed: () async {
              final fill = int.tryParse(fillController.text.trim());

              if (fill == null || fill < 0 || fill > 100) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Fill level must be between 0 and 100"),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }

              await _dbRef.child(key).update({
                "Name": nameController.text.trim(),
                "AreaId": areaController.text.trim(),
                "FillLevel": fill,
                "IsOverflowing": fill >= 100,
                "LastUpdate": "Updated manually",
              });

              if (!mounted) return;
              Navigator.of(dialogContext).pop();

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Bin updated successfully!"),
                  backgroundColor: Colors.blue,
                ),
              );
            },
            child: const Text(
              "Save Changes",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Color _fillColor(int fill) {
    if (fill >= 75) return Colors.red;
    if (fill >= 50) return Colors.orange;
    return Colors.green;
  }

  DataRow _buildBinRow(String key, dynamic bin) {
    final id = (bin['BinID'] ?? key).toString();
    final name = (bin['Name'] ?? 'N/A').toString();
    final area = (bin['AreaId'] ?? 'N/A').toString();
    final lastUpdate =
        (bin['LastUpdate'] ?? bin['lastUpdate'] ?? 'N/A').toString();
    final fill = int.tryParse((bin['FillLevel'] ?? 0).toString()) ?? 0;

    return DataRow(
      cells: [
        DataCell(
          Text(
            id,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.blueGrey,
            ),
          ),
        ),
        DataCell(Text(name)),
        DataCell(
          Row(
            children: [
              Icon(Icons.circle, size: 12, color: _fillColor(fill)),
              const SizedBox(width: 8),
              Text("$fill%"),
            ],
          ),
        ),
        DataCell(Text(area)),
        DataCell(Text(lastUpdate)),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit, size: 20, color: Colors.blue),
                onPressed: () => _showEditBinDialog(key, bin),
                tooltip: "Edit Bin",
              ),
              IconButton(
                icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                onPressed: () => _deleteBin(key),
                tooltip: "Delete Bin",
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return WebFrame(
      activeIndex: 1,
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Bin Management",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: _showAddBinDialog,
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text(
                    "Add New Bin",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF81C784),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: StreamBuilder(
                  stream: _dbRef.onValue,
                  builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData ||
                        snapshot.data!.snapshot.value == null) {
                      return const Center(child: Text("No bins found."));
                    }

                    final rawValue = snapshot.data!.snapshot.value;
                    List<DataRow> rows = [];

                    if (rawValue is Map) {
                      rawValue.forEach((key, value) {
                        if (value != null) {
                          rows.add(_buildBinRow(key.toString(), value));
                        }
                      });
                    } else if (rawValue is List) {
                      for (int i = 0; i < rawValue.length; i++) {
                        if (rawValue[i] != null) {
                          rows.add(_buildBinRow(i.toString(), rawValue[i]));
                        }
                      }
                    }

                    if (rows.isEmpty) {
                      return const Center(child: Text("No bins found."));
                    }

                    return LayoutBuilder(
                      builder: (context, constraints) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minWidth: constraints.maxWidth),
                            child: SingleChildScrollView(
                              child: DataTable(
                                headingRowColor:
                                    WidgetStateProperty.all(Colors.grey.shade100),
                                columnSpacing: 30,
                                columns: const [
                                  DataColumn(
                                    label: Text(
                                      "Bin ID",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Name",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Fill Level",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Area",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Last Update",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Actions",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                                rows: rows,
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}