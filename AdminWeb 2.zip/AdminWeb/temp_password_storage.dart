class TempPasswordStorage {
  static String? tempPassword;
  static String? identifier;
  static String? adminKey;
}