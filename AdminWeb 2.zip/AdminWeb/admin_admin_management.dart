import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'web_frame.dart';

class AdminManagementPage extends StatefulWidget {
  const AdminManagementPage({super.key});

  @override
  State<AdminManagementPage> createState() => _AdminManagementPageState();
}

class _AdminManagementPageState extends State<AdminManagementPage> {
  final DatabaseReference _dbRef =
      FirebaseDatabase.instance.ref('Baseer/admins');

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  String selectedRole = "admin";

  String hashPassword(String password) {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  bool isPhoneValid(String phone) {
    return RegExp(r'^\+9665[0-9]{8}$').hasMatch(phone);
  }

  bool isEmailValid(String email) {
    return RegExp(r'^[\w\-.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  String generateSecurePassword() {
    const uppers = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowers = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const specials = '!@#\$%^&*';
    final rnd = Random();

    String pass = '';
    pass += uppers[rnd.nextInt(uppers.length)];
    pass += lowers[rnd.nextInt(lowers.length)];
    pass += numbers[rnd.nextInt(numbers.length)];
    pass += specials[rnd.nextInt(specials.length)];

    const all = uppers + lowers + numbers + specials;
    for (int i = 0; i < 4; i++) {
      pass += all[rnd.nextInt(all.length)];
    }

    final chars = pass.split('');
    chars.shuffle(rnd);
    return chars.join('');
  }

  Future<void> sendEmail(
    String email,
    String name,
    String id,
    String password,
  ) async {
    const serviceId = 'service_k6q1xr4';
    const templateId = 'template_s41tpxh';
    const publicKey = 'C_LhjmeIfP-VVFNrw';

    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'service_id': serviceId,
        'template_id': templateId,
        'user_id': publicKey,
        'template_params': {
          'to_email': email,
          'to_name': name,
          'id': id,
          'password': password,
        }
      }),
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to send email.");
    }
  }

  void showAddAdminDialog() {
    _nameController.clear();
    _phoneController.clear();
    _emailController.clear();
    selectedRole = "admin";

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocalState) {
          Future<void> createAdmin() async {
            final name = _nameController.text.trim();
            final email = _emailController.text.trim();
            String phone = _phoneController.text.trim();

            if (name.isEmpty || email.isEmpty || phone.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Please fill all fields"),
                  backgroundColor: Colors.red,
                ),
              );
              return;
            }

            if (!isEmailValid(email)) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Enter a valid email"),
                  backgroundColor: Colors.red,
                ),
              );
              return;
            }

            if (phone.startsWith("5")) {
              phone = "+966$phone";
            }

            if (!isPhoneValid(phone)) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Enter a valid Saudi phone number: 5XXXXXXXX"),
                  backgroundColor: Colors.red,
                ),
              );
              return;
            }

            final snapshot = await _dbRef.get();
            int maxKey = 0;

            if (snapshot.exists && snapshot.value != null) {
              final raw = snapshot.value;

              if (raw is List) {
                for (int i = 0; i < raw.length; i++) {
                  if (raw[i] != null && i > maxKey) {
                    maxKey = i;
                  }
                }
              } else if (raw is Map) {
                final map = Map<dynamic, dynamic>.from(raw);
                for (final key in map.keys) {
                  final parsed = int.tryParse(key.toString()) ?? 0;
                  if (parsed > maxKey) maxKey = parsed;
                }
              }
            }

            final nextNumber = maxKey + 1;
            final adminID = "A$nextNumber";
            final rawPassword = generateSecurePassword();
            final hashedPassword = hashPassword(rawPassword);

            await _dbRef.child(nextNumber.toString()).set({
              "AdminID": adminID,
              "Name": name,
              "Email": email,
              "Phone": phone,
              "EmployeePass": hashedPassword,
              "Role": selectedRole,
            });

            await sendEmail(email, name, adminID, rawPassword);

            if (!context.mounted) return;
            Navigator.pop(context);

            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text(
                  "Success",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                content: const Text(
                  "Admin created and credentials sent by email.",
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("OK"),
                  )
                ],
              ),
            );
          }

          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: const Text(
              "Add New Admin",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            content: SizedBox(
              width: 400,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "A secure ID and password will be automatically generated and sent by email.",
                    style: TextStyle(color: Colors.grey, fontSize: 13),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: "Full Name",
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: "Email Address",
                      prefixIcon: Icon(Icons.email),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: "Phone Number (5XXXXXXXX)",
                      prefixIcon: Icon(Icons.phone),
                    ),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    value: selectedRole,
                    items: const [
                      DropdownMenuItem(
                        value: "admin",
                        child: Text("Admin"),
                      ),
                      DropdownMenuItem(
                        value: "supervisor",
                        child: Text("Supervisor"),
                      ),
                    ],
                    onChanged: (value) {
                      setLocalState(() {
                        selectedRole = value!;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: "Role",
                      prefixIcon: Icon(Icons.admin_panel_settings),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: createAdmin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF81C784),
                ),
                child: const Text(
                  "Create Admin",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void deleteAdmin(String key) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Admin"),
        content: const Text("Are you sure you want to delete this admin?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              _dbRef.child(key).remove();
              Navigator.pop(context);
            },
            child: const Text(
              "Delete",
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  DataRow _buildAdminRow(String key, dynamic value) {
    final adminId = (value['AdminID'] ?? 'N/A').toString();
    final name = (value['Name'] ?? 'N/A').toString();
    final email = (value['Email'] ?? 'N/A').toString();
    final phone = (value['Phone'] ?? 'N/A').toString();
    final role = (value['Role'] ?? 'admin').toString();

    return DataRow(
      cells: [
        DataCell(
          Text(
            adminId,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.blueGrey,
            ),
          ),
        ),
        DataCell(Text(name)),
        DataCell(Text(email)),
        DataCell(Text(phone)),
        DataCell(
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: role.toLowerCase() == 'supervisor'
                  ? Colors.blue.shade50
                  : Colors.green.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              role,
              style: TextStyle(
                color: role.toLowerCase() == 'supervisor'
                    ? Colors.blue
                    : Colors.green,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () => deleteAdmin(key),
                tooltip: "Delete Admin",
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WebFrame(
      activeIndex: 4,
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Admin Management",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: showAddAdminDialog,
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text(
                    "Add Admin",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2E7D32),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                    )
                  ],
                ),
                child: StreamBuilder(
                  stream: _dbRef.onValue,
                  builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData ||
                        snapshot.data!.snapshot.value == null) {
                      return const Center(child: Text("No admins found."));
                    }

                    final rawValue = snapshot.data!.snapshot.value;
                    List<DataRow> rows = [];

                    if (rawValue is Map) {
                      rawValue.forEach((key, value) {
                        if (value != null) {
                          rows.add(_buildAdminRow(key.toString(), value));
                        }
                      });
                    } else if (rawValue is List) {
                      for (int i = 0; i < rawValue.length; i++) {
                        if (rawValue[i] != null) {
                          rows.add(_buildAdminRow(i.toString(), rawValue[i]));
                        }
                      }
                    }

                    return LayoutBuilder(
                      builder: (context, constraints) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minWidth: constraints.maxWidth),
                            child: SingleChildScrollView(
                              child: DataTable(
                                columnSpacing: 30,
                                columns: const [
                                  DataColumn(
                                    label: Text(
                                      "ID",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Name",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Email",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Phone",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Role",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  DataColumn(
                                    label: Text(
                                      "Actions",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                                rows: rows,
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}