// lib/main.dart

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:basser/realtime_service.dart'; // Fixed import: now points to the service file

// Final Firebase Configuration using YOUR OFFICIAL PROJECT DETAILS
class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    // OFFICIAL VALUES from your Firebase Console
    apiKey: 'AIzaSyBgzhlooyfDirhNsYww63URZfMhhl2DDhE',
    appId: '1:1080961954717:web:b681c3466cac60d704f574',
    messagingSenderId: '1080961954717',
    projectId: 'baseer-40cf2',
    databaseURL: 'https://baseer-40cf2-default-rtdb.asia-southeast1.firebasedatabase.app', 
  );
}

void main() async {
  // Ensure Flutter is initialized before calling native services
  WidgetsFlutterBinding.ensureInitialized();
  print('--- WIDGETS INITIALIZED: STARTING FIREBASE CHECK ---'); 

  try {
    // 1. Initialize Firebase with the correct official options
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    print('FIREBASE: Initialization successful. Starting console tests.');

    // 2. Run the connection and CRUD tests
    await runConsoleTests();
  } catch (e) {
    // This handler will catch any critical failure during setup
    print('!!!!!!!!!! FIREBASE FAILED TO INITIALIZE !!!!!!!!!');
    print('ERROR DETAILS: $e');
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'RTDB Tester',
      home: Scaffold(
        body: Center(
          child: Text(
            'Realtime DB Test Running.\nCheck the Chrome Console!',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, color: Colors.blueGrey),
          ),
        ),
      ),
    );
  }
}