// lib/realtime_service.dart

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart'; // Only needed for debugging, but good practice

// Get a reference to the Firebase Realtime Database
final DatabaseReference _dbRef = FirebaseDatabase.instance.ref();

// --- CRUD Functions for Bins ---

Future<String> addTestBin(String name) async {
  try {
    // Generate a unique key for the new bin entry under the 'Bins' path
    final newBinRef = _dbRef.child('bins').push();
    final String binId = newBinRef.key!;

    await newBinRef.set({
      'Name': name,
      'AreaId': 'Riyadh-T',
      'FillLevel': 10,
      'Capacity': 120,
      'Timestamp': DateTime.now().toIso8601String(),
    });

    print('CONSOLE: ✅ Bin added successfully! ID: $binId');
    return binId;
  } catch (e) {
    print('CONSOLE: ❌ Failed to add bin: $e');
    return '';
  }
}

Future<void> updateTestBin(String binId) async {
  try {
    await _dbRef.child('Bins/$binId').update({
      'FillLevel': 95,
      'IsOverflowing': true,
      'Timestamp': DateTime.now().toIso8601String(),
    });
    print('CONSOLE: ✅ Bin updated successfully! ID: $binId');
  } catch (e) {
    print('CONSOLE: ❌ Failed to update bin: $e');
  }
}

Future<void> deleteTestBin(String binId) async {
  try {
    await _dbRef.child('Bins/$binId').remove();
    print('CONSOLE: ✅ Test bin successfully deleted. ID: $binId');
  } catch (e) {
    print('CONSOLE: ❌ Failed to delete bin: $e');
  }
}

// --- Test Execution ---

Future<void> runConsoleTests() async {
  print('------------------------------------------------');
  print('TEST START: Verifying Realtime Database Connection and Functions');
  print('------------------------------------------------');

  // 1. ADD: Create a new bin
  String testBinId = await addTestBin('Test-Bin-RTDB');
  await Future.delayed(const Duration(milliseconds: 500));

  if (testBinId.isNotEmpty) {
    // 2. EDIT: Update the bin
    print('TEST 2: Bin found ($testBinId). Updating fill level...');
    await updateTestBin(testBinId);
    await Future.delayed(const Duration(milliseconds: 500));

    // 3. DELETE: Clean up the test bin
    //print('TEST 3: Cleaning up (Deleting test bin)...');
   // await deleteTestBin(testBinId);
  //} else {
  //  print('TEST 2 & 3 SKIPPED: Cannot run due to failed ADD operation.');
  }

  print('------------------------------------------------');
  print('TEST COMPLETE: Check your Firebase Realtime DB console for confirmation!');
}